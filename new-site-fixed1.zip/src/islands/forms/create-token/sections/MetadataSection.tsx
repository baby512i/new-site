import type { UseFormReturn } from "react-hook-form";
import { FormSection } from "../../components/FormSection";
import { FormField } from "../../components/FormField";
import { TextArea } from "../../components/TextArea";
import { ImageUploadField } from "../../components/ImageUploadField";
import { SocialLinksFields } from "../fields/SocialLinksFields";
import type { CreateTokenValues } from "../../../../lib/validation/create-token/create-token.schema";
import type { PlatformFieldVisibility } from "../utils/get-platform-field-visibility";
import {
  getFieldErrorMessage,
  isFieldInvalid,
} from "../utils/form-errors";

interface MetadataSectionProps {
  id: string;
  visibility: PlatformFieldVisibility;
  form: UseFormReturn<CreateTokenValues>;
  imageFile: File | null;
  onImageChange: (file: File | null) => void;
  imageError?: string;
  onImageBlur?: () => void;
}

export function MetadataSection({
  id,
  visibility,
  form,
  imageFile,
  onImageChange,
  imageError,
  onImageBlur,
}: MetadataSectionProps) {
  const {
    register,
    formState: { errors },
  } = form;

  return (
    <FormSection
      id={id}
      title="Metadata"
      description="Describe the token and add the image shown on explorers."
    >
      <FormField
        htmlFor="description"
        label="Description"
        optional
        error={getFieldErrorMessage(errors, "description")}
        hint="Up to 500 characters. Plain text, no HTML."
      >
        <TextArea
          id="description"
          placeholder="Short description of what the token represents."
          maxLength={500}
          invalid={isFieldInvalid(errors, "description")}
          {...register("description")}
        />
      </FormField>

      {visibility.showImageUpload ? (
        <>
          <ImageUploadField
            fieldId="tokenImage"
            label="Token image"
            required
            hint="PNG, JPEG, WebP, or GIF. Max 2 MB. Square images render best."
            value={imageFile}
            onChange={onImageChange}
            onBlur={onImageBlur}
            error={imageError}
          />
          <p className="text-xs leading-5 text-[var(--color-text-muted)]">
            Token image may need to be re-uploaded after switching token type.
          </p>
        </>
      ) : null}

      <SocialLinksFields form={form} visible={visibility.showSocialLinks} />
    </FormSection>
  );
}
