import type { TokenImageDraft } from "./create-token-draft-storage";

const MAX_IMAGE_BYTES = 2 * 1024 * 1024;

const ALLOWED_IMAGE_TYPES = new Set([
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif",
]);

export async function fileToTokenImageDraft(
  file: File,
): Promise<TokenImageDraft | null> {
  if (file.size > MAX_IMAGE_BYTES) return null;
  if (!ALLOWED_IMAGE_TYPES.has(file.type)) return null;

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result;
      if (typeof result !== "string") {
        resolve(null);
        return;
      }
      const commaIndex = result.indexOf(",");
      const base64 = commaIndex >= 0 ? result.slice(commaIndex + 1) : result;
      if (!base64) {
        resolve(null);
        return;
      }
      resolve({
        fileName: file.name,
        mimeType: file.type,
        base64,
      });
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export function tokenImageDraftToFile(draft: TokenImageDraft): File {
  const binary = atob(draft.base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new File([bytes], draft.fileName, { type: draft.mimeType });
}
