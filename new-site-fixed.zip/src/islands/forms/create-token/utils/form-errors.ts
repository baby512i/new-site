import type { FieldErrors } from "react-hook-form";
import type { CreateTokenValues } from "../../../../lib/validation/create-token/create-token.schema";

/**
 * Lookup helpers for RHF errors on a discriminated-union form.
 *
 * `useForm<CreateTokenValues>` produces `FieldErrors<CreateTokenValues>`, but
 * because every platform branch has a different shape, the typed `errors.foo`
 * narrows to never on cross-branch fields. Sections only need:
 *   - "is there an error on key X?"
 *   - "what is the message string for key X?"
 * so we widen `errors` to a string-keyed lookup at the helper boundary.
 */
type ErrorBag = FieldErrors<CreateTokenValues>;

type ErrorEntry = { message?: unknown; type?: unknown } | undefined;

function lookupEntry(errors: ErrorBag, key: string): ErrorEntry {
  return (errors as unknown as Record<string, ErrorEntry>)[key];
}

export function getFieldErrorMessage(
  errors: ErrorBag,
  key: string,
): string | undefined {
  const entry = lookupEntry(errors, key);
  if (!entry) return undefined;
  return typeof entry.message === "string" ? entry.message : undefined;
}

export function isFieldInvalid(errors: ErrorBag, key: string): boolean {
  return Boolean(lookupEntry(errors, key));
}
