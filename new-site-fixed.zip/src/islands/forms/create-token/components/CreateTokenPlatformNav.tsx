import {
  listCreateTokenPlatforms,
  type CreateTokenPlatform,
} from "../../../../lib/tool-config/create-token-platforms";

const NAV_LABELS: Record<CreateTokenPlatform, string> = {
  spl: "SPL Token",
  taxToken: "Tax Token",
  pumpfun: "Pump Fun",
  raydiumLaunchlab: "LaunchLab",
  meteoraDbc: "Meteora DBC",
};

interface CreateTokenPlatformNavProps {
  activePlatformId: CreateTokenPlatform;
  isUmbrella?: boolean;
}

export function CreateTokenPlatformNav({
  activePlatformId,
  isUmbrella = false,
}: CreateTokenPlatformNavProps) {
  const platforms = listCreateTokenPlatforms();

  return (
    <section
      aria-labelledby="create-token-platform-nav-heading"
      className="create-token-type-nav grid gap-4 rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-surface-muted)] p-4 sm:p-5"
    >
      <h2
        id="create-token-platform-nav-heading"
        className="text-base font-semibold tracking-[var(--tracking-heading)] text-[var(--color-text)] sm:text-lg"
      >
        Select Token Type
      </h2>

      <nav
        aria-label="Token types"
        role="radiogroup"
        aria-labelledby="create-token-platform-nav-heading"
      >
        <ul className="flex flex-wrap items-center gap-x-6 gap-y-3" role="list">
          {platforms.map((platform) => {
            const active = !isUmbrella && platform.id === activePlatformId;
            return (
              <li key={platform.id}>
                <a
                  href={platform.url}
                  role="radio"
                  aria-checked={active}
                  aria-current={active ? "page" : undefined}
                  className={[
                    "create-token-type-option",
                    active ? "create-token-type-option--active" : "",
                  ]
                    .filter(Boolean)
                    .join(" ")}
                >
                  <span className="create-token-type-radio" aria-hidden="true">
                    <span className="create-token-type-radio__dot" />
                  </span>
                  <PlatformNavIcon platformId={platform.id} />
                  <span className="text-sm font-medium text-[var(--color-text)]">
                    {NAV_LABELS[platform.id]}
                  </span>
                </a>
              </li>
            );
          })}
        </ul>
      </nav>
    </section>
  );
}

function PlatformNavIcon({ platformId }: { platformId: CreateTokenPlatform }) {
  const className = "h-4 w-4 shrink-0";

  if (platformId === "pumpfun") {
    return (
      <svg className={className} viewBox="0 0 200 200" fill="none" aria-hidden="true">
        <path
          d="M21.8855 184.247C-2.01603 162.076 -3.41853 124.726 18.753 100.824L94.7609 18.8855C116.932 -5.01605 154.282 -6.41855 178.184 15.7529C202.085 37.9244 203.488 75.274 181.316 99.1756L105.308 181.115C83.1367 205.016 45.7871 206.419 21.8855 184.247Z"
          fill="white"
        />
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M18.753 100.824C-3.41853 124.726 -2.01603 162.076 21.8855 184.247C45.7871 206.419 83.1367 205.016 105.308 181.115L145.81 137.452L59.2549 57.1621L18.753 100.824Z"
          fill="#5FCB88"
        />
      </svg>
    );
  }

  if (platformId === "raydiumLaunchlab") {
    return (
      <svg className={className} viewBox="0 0 29 33" fill="none" aria-hidden="true">
        <defs>
          <linearGradient
            id="create-token-raydium-nav-gradient"
            x1="28.3168"
            y1="8.19162"
            x2="-1.73336"
            y2="20.2086"
            gradientUnits="userSpaceOnUse"
          >
            <stop stopColor="#C200FB" />
            <stop offset="0.489658" stopColor="#3772FF" />
            <stop offset="1" stopColor="#5AC4BE" />
          </linearGradient>
        </defs>
        <g fill="url(#create-token-raydium-nav-gradient)">
          <path d="M26.8625 12.281V23.6914L14.1709 31.0175L1.47231 23.6914V9.03203L14.1709 1.69881L23.925 7.33322L25.3973 6.48381L14.1709 0L0 8.18262V24.5408L14.1709 32.7234L28.3419 24.5408V11.4316Z" />
          <path d="M10.6176 23.6985H8.49407V16.5776H15.5725C16.2422 16.5702 16.8819 16.2994 17.3535 15.8239C17.8251 15.3484 18.0905 14.7063 18.0923 14.0365C18.0961 13.7054 18.0322 13.3769 17.9044 13.0714C17.7765 12.7658 17.5876 12.4899 17.349 12.2601C17.1182 12.0229 16.8419 11.8348 16.5366 11.7071C16.2313 11.5793 15.9033 11.5146 15.5725 11.5168H8.49407V9.35083H15.5795C16.82 9.35826 18.0077 9.85434 18.8848 10.7315C19.7619 11.6086 20.258 12.7962 20.2654 14.0365C20.273 14.9861 19.9835 15.9142 19.4373 16.6909C18.9346 17.4341 18.2262 18.0146 17.3987 18.3614C16.5793 18.6214 15.724 18.7504 14.8642 18.7432H10.6176Z" />
          <path d="M20.2159 23.5215H17.7384L15.8273 20.1876C16.5834 20.1413 17.3292 19.9888 18.0428 19.7346Z" />
          <path d="M25.3831 9.90975L26.8483 10.7238L28.3136 9.90975V8.1897L26.8483 7.34029L25.3831 8.1897Z" />
        </g>
      </svg>
    );
  }

  if (platformId === "meteoraDbc") {
    return (
      <svg className={className} viewBox="0 0 240 240" fill="none" aria-hidden="true">
        <defs>
          <linearGradient
            id="create-token-meteora-nav-gradient"
            x1="236.796"
            y1="22.2322"
            x2="67.9085"
            y2="217.509"
            gradientUnits="userSpaceOnUse"
          >
            <stop stopColor="#F5BD00" />
            <stop offset="0.364891" stopColor="#F54B00" />
            <stop offset="1" stopColor="#6E45FF" />
          </linearGradient>
        </defs>
        <path
          d="M185.89 66.8866C189.203 63.5733 194.335 63.7681 196.457 67.2763C198.753 71.0443 200.486 75.1156 201.72 79.3817C202.413 81.8069 201.611 84.6433 199.598 86.6571L134.696 151.559C130.777 155.479 125.904 158.185 120.729 159.29L115.336 160.437C110.182 161.563 105.266 164.271 101.368 168.169L51.5392 217.998C49.417 209.812 48.4857 204.29 55.134 197.641L185.89 66.8866ZM199.945 94.8475C202.111 92.6821 205.446 93.9384 205.23 96.7968C203.887 114.294 195.55 132.723 180.695 147.579C169.369 159.988 137.405 178.958 114.559 191.67C109.881 194.268 106.069 188.725 109.903 184.891L199.924 94.87L199.945 94.8475ZM170.081 40.6425C172.138 38.5853 175.17 38.1527 177.249 39.5819C181.58 42.5271 185.63 46.7932 187.709 51.9472C188.489 53.9394 187.817 56.3868 186.107 58.0975L116.202 128.001C112.283 131.92 107.41 134.628 102.235 135.732L96.8429 136.88C91.6891 138.006 86.7731 140.713 82.8752 144.61L39.759 187.726C37.6368 179.541 38.6547 172.07 45.3029 165.422L70.466 140.258L170.081 40.6425ZM140.455 28.2157C144.353 24.3178 149.94 22.8017 154.531 24.5341C157.412 25.6385 160.184 26.9815 162.804 28.5624C166.269 30.6414 166.442 35.7086 163.194 38.9569L99.2668 102.884C95.607 106.543 90.6257 108.493 85.8615 108.146C80.8592 107.778 75.5971 109.836 71.7209 113.712L36.7043 148.728C34.582 140.543 37.3324 131.339 43.9806 124.69L140.455 28.2157ZM130.215 21.9989C133.29 21.9558 134.481 25.6162 132.142 27.955L98.9445 61.1522L71.2258 88.872L64.1877 95.9091L53.4025 106.694C51.1503 108.946 47.8155 106.91 49.0715 104.052L59.5529 80.2313C60.1376 78.7804 60.7875 77.3076 61.5021 75.8134L61.5666 75.662C67.6084 62.8636 77.3323 49.285 86.4709 40.1464C101.132 25.4858 114.298 22.1505 130.215 21.9989Z"
          fill="url(#create-token-meteora-nav-gradient)"
        />
      </svg>
    );
  }

  return null;
}
